<?php
// Database configuration
$host = 'localhost';
$dbname = 'axrqihis_inventory';
$username = 'axrqihis_inventory';
$password = '1qu37dyyq689';

try {
    // Create a new PDO instance with DSN
    $conn = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);

    // Set PDO attributes
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); // Enable exceptions for errors
    $conn->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC); // Set default fetch mode
} catch (PDOException $e) {
    // Handle connection errors
    exit("Database connection failed: " . $e->getMessage());
}
?>